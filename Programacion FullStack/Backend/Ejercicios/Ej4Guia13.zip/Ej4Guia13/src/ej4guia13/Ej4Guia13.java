package ej4guia13;

import java.util.Scanner;

/*Todas estas operaciones puede tirar excepciones a manejar, el ingreso por teclado puede
causar una excepción de tipo InputMismatchException, el método Integer.parseInt() si la cadena
no puede convertirse a entero, arroja una NumberFormatException y además, al dividir un
número por cero surge una ArithmeticException. Manipule todas las posibles excepciones
utilizando bloques try/catch para las distintas excepciones*/
/**
 *
 * @author PC
 */
public class Ej4Guia13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese un primer número");
        String n1 = leer.next();
        System.out.println("Ingrese un segundo número");
        String n2 = leer.next();
       // if(n1.isEmpty()||n2.isEmpty()){
            
       // }
        try{
        int num1 = Integer.parseInt(n1);
        int num2 = Integer.parseInt(n2);
        System.out.println("La división entre ambos números es: " + num1/num2);}
        catch(NumberFormatException nfe){
            System.out.println("La cadena no puede convertirse a entero " + nfe.fillInStackTrace());
        }
        catch(ArithmeticException ae){
            System.out.println("No es posible realizar una división por 0 " + ae.getMessage());
        }
        catch(Exception e){
            System.out.println("Tenés un error raro " + e.getMessage());
        }
        finally{
            System.out.println("Saliendo del programa");
        }
    }

}
