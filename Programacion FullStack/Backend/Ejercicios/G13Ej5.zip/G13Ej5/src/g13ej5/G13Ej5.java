package g13ej5;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class G13Ej5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        Random rand = new Random();
        int numero = rand.nextInt(500);
        int adivinanza = 1000;
        boolean ganaste = false;
        int contador = 0;
        do {

            contador++;
            System.out.println("Introduce un numero entre 1 y 500:  (0 para salir)");
            try {
                adivinanza = Integer.parseInt(sc.next());
                if (numero == adivinanza) {
                    System.out.println("Adivinaste!");
                    ganaste = true;
                } else {
                    System.out.println(((numero < adivinanza) ? "Tu numero es mas grande!"
                            : "Tu numero es mas chico!"));
                }
            } catch (InputMismatchException e) {
                System.out.println("No ingresaste un numero entero." + e.fillInStackTrace());
            } catch (Exception e) {
                System.out.println("no funca nada" + e.getMessage());

            } finally {

                if (adivinanza != 0) {
                    if (ganaste) {
                        System.out.println("Ganaste en " + contador);
                        System.out.println("Queres seguir jugando? (S/N)");
                        String opcion = sc.next().toUpperCase();
                        if (opcion.equals("N")) {
                            adivinanza = 0;
                        } else {
                            adivinanza = 1000;
                            ganaste = false;
                            numero = rand.nextInt(500);
                            contador = 0;

                        }
                    }
                }
            }
        } while (adivinanza != 0);
    }
}
