/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej3guia12;


class DivisonNumero {
    
    public double division(int n1,int n2){
        
       double div = n1/n2;
        return div;
        
    }
    
    
}
