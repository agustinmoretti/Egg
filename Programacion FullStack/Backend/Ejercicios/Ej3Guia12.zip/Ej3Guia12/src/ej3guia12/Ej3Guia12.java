package ej3guia12;

import java.util.Scanner;

public class Ej3Guia12 {

    public static void main(String[] args) {

       DivisonNumero dv = new DivisonNumero();
        Scanner input = new Scanner(System.in, "ISO-8859-1")
        .useDelimiter("\n");
        boolean bandera = true;
        do {
            System.out.println("Ingrese dos numeros");
            String num1 = input.next();
            String num2 = input.next();
            try {
                int numConv1 = Integer.parseInt(num1);
                int numConv2 = Integer.parseInt(num2);
                System.out.println("La division de " + numConv1 + " y" + numConv2
                +" =" +dv.division(numConv1, numConv2));
                bandera = false;
        } catch (Exception e) {
                    System.out.println("msj error " + e.getMessage());
                }
    }
    while (bandera);
        
                
}

}
